"""Deterministic mismatch shrinker (delta debugging for our sequences).

`shrink(sequence, reproduces)` — given a full sequence that produced a
divergence, return the smallest prefix that still reproduces a divergence.
Deterministic: same input always yields the same output, so the counterexample
is a stable, communicable artifact ("the shortest prefix where the simulator
disagrees with the reference").
"""

from __future__ import annotations

from collections.abc import Callable

from reality_bridge.sequences import Action


def shrink(sequence: list[Action], reproduces: Callable[[list[Action]], bool]) -> list[Action]:
    """Return the shortest prefix of `sequence` that still reproduces a divergence.

    `reproduces(prefix)` drives the pair fresh and returns True if any
    divergence occurs anywhere in the prefix. Binary-search the length, then
    tighten to the earliest divergent step within that length. The result is a
    prefix of the original sequence, never a reordering.
    """
    if not sequence:
        return []

    # smallest length L in [1, len(sequence)] whose prefix reproduces
    lo, hi = 1, len(sequence)
    while lo < hi:
        mid = (lo + hi) // 2
        if reproduces(sequence[:mid]):
            hi = mid
        else:
            lo = mid + 1
    return sequence[:lo]
