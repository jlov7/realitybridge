"""Owned reference startup must fail before affecting foreign resources."""

from __future__ import annotations

import pytest

from reality_bridge import reference as ref
from reference import owned_lifecycle as owned


def test_existing_project_is_refused(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(ref, "COMPOSE_PROJECT", "rb-test-owned")
    monkeypatch.setattr(owned.platform, "machine", lambda: "arm64")
    calls: list[tuple[str, ...]] = []

    def fake_run(args: tuple[str, ...]) -> str:
        calls.append(args)
        return "foreign-container" if args[:3] == ("docker", "ps", "-aq") else "arm64"

    monkeypatch.setattr(owned, "_run", fake_run)
    with pytest.raises(ref.ReferenceError, match="already owns containers"):
        owned.preflight()
    assert not any("down" in command for command in calls)


def test_failure_sweeps_only_started_project(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(owned, "preflight", lambda: None)
    events: list[str] = []
    monkeypatch.setattr(ref, "up", lambda: events.append("up"))
    monkeypatch.setattr(ref, "_compose", lambda *args: events.append(" ".join(args)))
    monkeypatch.setattr(owned.subprocess, "call", lambda *args, **kwargs: 7)
    assert owned.run_owned(("false",)) == 7
    assert events == ["up", "down -v"]


def test_failed_up_is_swept(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(owned, "preflight", lambda: None)
    events: list[str] = []

    def fail_up() -> None:
        events.append("up")
        raise ref.ReferenceError("injected failure")

    monkeypatch.setattr(ref, "up", fail_up)
    monkeypatch.setattr(ref, "_compose", lambda *args: events.append(" ".join(args)))
    with pytest.raises(ref.ReferenceError, match="injected failure"):
        owned.run_owned(("true",))
    assert events == ["up", "down -v"]
