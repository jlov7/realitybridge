# Related work — scope differences

Verified 2026-09-21 against primary sources. Every prior-art entry below was confirmed present and correctly characterised. Prior art **sharpens** the contribution; it does not license a novelty claim.

| Work | Already covers | Our boundary |
|---|---|---|
| **SynAE** — arXiv:2605.22564 | Measuring synthetic trajectory validity, fidelity, diversity, downstream ranking agreement | Measures quality **after the fact**. We generate *and repair* an executable simulator against a live reference. |
| **Agent-Diff** — arXiv:2602.11224 | Enterprise API replicas + state-diff contracts; code-execution task evaluation | Provides replicas. Does not shrink a divergence to a minimal counterexample and drive a bounded repair loop against a pinned real service. |
| **When Simulation Lies / RobustBench-TC** — arXiv:2605.11928 | Sim-to-real perturbation benchmark + domain-randomised RL recipe | Trains a response to a sim-to-real gap. We repair the simulator itself and quantify residual mismatch. |
| **OPINE-World** — arXiv:2607.01531 | Programmatic world modelling, ontology-error-prioritised corrective exploration | Game environments. Counterexample-guided repair is not ours to claim. |
| **LearnLib** | Automata learning, conformance testing | Classical model learning. Established technique; we do not invent it. |
| **RESTler** — microsoft/restler-fuzzer | Stateful API fuzzing | Incumbent strong baseline. If our approach does not beat/beat-at-lower-cost this class of tooling, that is a real finding. |
| **nanoAWM** (author's own) | Consequence prediction/planning in an **authored** MiniOS | RealityBridge's reference is an **independently implemented** application. Different problem: constructing the environment, not predicting inside it. |
| **BranchLab** (author's own) | Counterfactual trace debugging, inspectable traces | Supplies experience. RealityBridge must not become a layer on BranchLab. |

## Explicit non-claims

- Not first to test a simulator. Not first to use state differences. Not first to compare rankings. Not first to use counterexample-guided repair.
- Not bisimulation or complete semantic equivalence.
- Not independent human validation — a separate process by the same author is not independence.
- Matching a reference bug establishes **fidelity to that version**, not correctness or safety.

## Verified source record

| Source | Verified how | Date |
|---|---|---|
| arXiv:2605.22564 (SynAE) | HTTPS 200, title matched | 2026-09-21 |
| arXiv:2602.11224 (Agent-Diff) | HTTPS 200, title matched | 2026-09-21 |
| arXiv:2605.11928 (When Simulation Lies) | HTTPS 200, title matched | 2026-09-21 |
| arXiv:2607.01531 (OPINE-World) | HTTPS 200, title matched | 2026-09-21 |
| Gitea 1.24 API docs | HTTPS 200 | 2026-09-21 |
| `gitea/gitea` 1.24 tags | Docker Hub API 200; `1.24.0`–`1.24.2` + rootless variants present | 2026-09-21 |
