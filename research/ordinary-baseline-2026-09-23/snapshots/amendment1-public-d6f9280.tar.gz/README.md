# RealityBridge

RealityBridge is a bounded local study of a six-operation issue and label
simulator against one pinned Gitea reference. It compares action responses and
the full declared issue, label and membership state after every action. The
simulator is a research artifact, not a general Gitea replacement.

The [2026-09-22 finite study](docs/research-completion-2026-09-22/RESULTS.md)
completed under its predeclared protocol. At matched observed HTTP cost, the
fixed targeted order found three divergent development cases versus one or two
for each of three random orders. Three of 16 new evaluation cases diverged.
Scripted policy selection had no rank disagreement or simulator-caused regret
in the measured task instances. These are authored local observations; they do
not establish a population-level probing advantage or general policy impact.

The measured candidate at `19b2b4776b538ca5bf7326118fe6fcdae7f21cd2`
was deliberately imperfect. Its raw result and exact source are preserved.
After measurement, the current default simulator was repaired for the known
leading-hash color rule and three label edge cases. A separate regression run
found agreement on all 30 now-exposed cases and three P05 policy final states.
That later run is engineering requalification, not a new prospective result.

## Evidence and reproduction

- Frozen design: [PROTOCOL.md](docs/research-completion-2026-09-22/PROTOCOL.md).
- Result, claim limits and commands: [RESULTS.md](docs/research-completion-2026-09-22/RESULTS.md).
- Raw measured attempt: `artifacts/research-completion-2026-09-22/attempt-20260922T182622Z-59359/`.
- Current simulator regression receipt: `artifacts/research-completion-2026-09-22/post-study-requalification-20260922T183442Z-62290.json`.
- Exact baseline emulator source: `experiments/research_baseline_emulator_19b2b47.py`.

The baseline materializer creates a separate local source tree with the exact
measured emulator bytes. Use an environment with the locked development
dependencies. The original raw receipt can then be recomputed without Docker
or the private Git history:

```bash
python experiments/materialize_research_baseline.py /private/tmp/rb-baseline
cd /private/tmp/rb-baseline
PYTHONPATH=src:. python experiments/reproduce_research_completion.py \
  /absolute/path/to/realitybridge/artifacts/research-completion-2026-09-22/attempt-20260922T182622Z-59359
```

For a fresh live baseline run, use the materialized tree and set
`REALITYBRIDGE_COMPOSE_PROJECT=rb-research-20260922` and
`REALITYBRIDGE_PORT=13002`. Run `experiments/research_completion.py` there.
It creates a new attempt directory, requires a clean committed local source
tree, and checks the frozen protocol hash. Only the named isolated Compose
project may be cleaned up afterward. The historical raw attempt is immutable.

To check the current repaired simulator against the now-exposed cases, run
`experiments/post_study_requalification.py` in the normal tree with the same
isolated Compose settings. It retains a separate receipt. The older
`experiments/repair_demo.py` requires the materialized baseline so that its
before/after color repair still has the intended counterexample.

## Package and tests

The wheel contains the core Python package. Reference lifecycle commands
require a source checkout with `reference/compose.yaml` and
`reference/seed.py`. Development dependencies and tests are declared in
`pyproject.toml` and `uv.lock`. Offline checks can run without Docker;
container-backed tests require the isolated reference. The macOS worker test
requires a host that permits `sandbox-exec`.

This repository has no hosted CI result, external validation, publication or
release approval. The earlier response-only results remain as historical
evidence under `artifacts/evidence/` and are not substituted for the corrected
full-state study.
